/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycharlie.plugin;
import charlie.card.Shoe;
import java.util.Random;


/**
 *
 * @author Vivek Vellaiyappan Surulimuthu | vivekvellaiyappans@gmail.com | Vivek.Surulimuthu1@marist.edu
 */
public class MyShoe01 extends Shoe {
    
    public MyShoe01(){
        super(2);
    }
/*    
    @Override
    public void init() {
        super.ran = new Random(/*1*///);
  /*                      
        super.numDecks = 1;
        
        // Loads all cards in the deck containing 52 cards
        super.load();
        
        // Shuffles the cards
        super.shuffle();
    }
  */
}
